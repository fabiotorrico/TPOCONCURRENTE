/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tpparque;

import java.util.Random;

/**
 *
 * @author Fabio
 */
public class Parque {

    private boolean estaAbierto;
    private CarreraDeGomones unaCa;
    private Faro unFaro;
    private Restaurante[] restaurantes;
    private Snorkel unSnorkel;
    private NadoConDelfines delfines;

    public Parque(CarreraDeGomones unaCa, Faro unFaro, Restaurante[] restaurantes, Snorkel snorkel, NadoConDelfines undelf) {
        //Constructor
        this.estaAbierto = true;
        this.unaCa = unaCa;
        this.unFaro = unFaro;
        this.restaurantes = restaurantes;
        this.unSnorkel = snorkel;
        this.delfines = undelf;
    }

    public boolean abierto() {
        return estaAbierto;
    }

    public void setAbierto(boolean hora) {
       estaAbierto=hora;
       
    }

    public void actividadGomones(Persona unaP) {
        //El modulo Realiza la Carrera de Gomones.
        try {
            if (estaAbierto) {// Si el Parque aun Esta Abierto Realizo la Actividad. 
                unaCa.empiezaActividad(unaP);
                unaCa.simuloViaje(unaP);
                unaCa.llegarAlaActividad(unaP);
                unaCa.guardarCosas(unaP);
                unaCa.subirGomon(unaP);
                unaCa.bajar(unaP);
                unaCa.meta(unaP);
                unaCa.retirarCosas(unaP);
            } else {
                System.out.println(unaP.getNombre() + " No pudo Hacer La Carrera de Gomones por que El Parque Ya cerro");
            }

        } catch (Exception e) {
        }

    }

    public void actividadFaro(Persona unaP) {
        //El modulo se Encarga de que la Persona suba al Faro.

        if (estaAbierto) {// Si el Parque aun Esta Abierto Realizo la Actividad.
            unFaro.ingresar(unaP);
            unFaro.bajarPorElTobogan(unaP);
        } else {
            System.out.println(unaP.getNombre() + " No pudo Subir al FARO por que el esta Parque CERR0");
        }

    }

    public void actividadComer(Persona unaP) {
        //El modulo se escarga de que la Persona valla a (almorzar o Merendar) en alguno de los restaurantes del Parque.
        try {
            if (estaAbierto) {// Si el Parque aun Esta Abierto Realizo la Actividad.
                while (!unaP.getComio() && estaAbierto) {
                    Random r = new Random();
                    int x = r.nextInt(restaurantes.length) + 1;
                    restaurantes[0].entrarAcomer(unaP);
                    restaurantes[0].comiendo(unaP);
                    restaurantes[0].terminoComer(unaP);
                }
            } else {
                System.out.println(unaP.getNombre() + " No pudo Ingresar al Restaurante por que El Parque Ya cerro");
            }

        } catch (Exception e) {
        }

    }

    public void actividadaSnorkel(Persona unaP) {
        try {
            if (estaAbierto) {
                unSnorkel.entrar(unaP);
                unSnorkel.adquirirAccesorios(unaP);
                unSnorkel.simulacionActividad();
                unSnorkel.terminarActividad(unaP);
            } else {
                System.out.println(unaP.getNombre() + " No pudo Ingresar a los Snorkel por que El Parque Ya cerro");
            }
        } catch (Exception e) {
        }
    }

    public void actividadDelfines(Persona unaP) {
        Random random = new Random();
        try {
            if (estaAbierto) {
                 switch (random.nextInt(4)) {
                case 0:
                    delfines.entroPile1(unaP);
                    delfines.nadar1(unaP);
                    delfines.salirPile1(unaP);
                    break;
                case 1:
                    delfines.entroPile2(unaP);
                    delfines.nadar2(unaP);
                    delfines.salirPile2(unaP);
                    break;
                case 2:
                    delfines.entroPile3(unaP);
                    delfines.nadar3(unaP);
                    delfines.salirPile3(unaP);
                    break;
                case 3:
                    delfines.entroPile4(unaP);
                    delfines.nadar4(unaP);
                    delfines.salirPile4(unaP);
                    break;

            }
            } else {
                  System.out.println(unaP.getNombre() + " No pudo Ingresar a Nadar con Delfines por que El Parque Ya cerro");
            }
        } catch (Exception e) {
        }
    }

    public void entrarParque(Persona unaP) {
      Random r = new Random();
         // Si el Parque aun Esta Abierto Realizo la Actividades Aleatoriamente.          
        while (estaAbierto) {             
        switch (r.nextInt(5)) {
            case 0:
                actividadComer(unaP);
                break;
            case 1:
                actividadFaro(unaP);
                break;
            case 2:
                actividadGomones(unaP);
                break;
            case 3:
                actividadaSnorkel(unaP);
                break;
            case 4: 
                actividadDelfines(unaP);
                break;
        }   
        }
    }
    
}
