/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tpparque;

import java.util.Random;
import java.util.concurrent.Semaphore;

/**
 *
 * @author fabio
 */
public class Shop {

    private Semaphore caja1;
    private Semaphore caja2;
    private Semaphore fila;

    public Shop() {
        this.caja1 = new Semaphore(1, true);
        this.caja2 = new Semaphore(1, true);
        this.fila = new Semaphore(1, true);
    }

    public void ingreso(Persona unaP) {
        System.out.println(unaP.getNombre() + " Ingreso al SHOP ");
        observar(unaP);
        salir(unaP);
    }

    private void observar(Persona unaP) {
        Random r = new Random();
        try {
            System.out.println(unaP.getNombre() + " Esta observando los subeniles");
            Thread.sleep(1000 * r.nextInt(4));
            if (r.nextInt(1) == 0) {
                System.out.println(unaP.getNombre() + "No quiere comprar nada");          
            } else {
                System.out.println(unaP.getNombre() + "Decide Comprar y elije sus productos");
                comprar(unaP);
            }
        } catch (Exception e) {
        }
    }

    private void comprar(Persona unaP) {
        System.out.println(unaP.getNombre() + " Hace fila para PAGAR");
        try {
            fila.acquire();
            if (caja1.tryAcquire()) {
                pagar(unaP, "Caja 1");
                caja1.release();
            } else {
                caja2.acquire();
                pagar(unaP, "Caja 2");
                caja2.release();
            }
            fila.release();
        } catch (Exception e) {
        }
    }

    private void pagar(Persona unaP, String caja) {
        try {
            Random r = new Random();
            System.out.println(unaP.getNombre() + " Esta Pagando en " + caja);
            Thread.sleep(1000 * r.nextInt(3) + 1);
        } catch (Exception e) {
        }
    }

    public void salir(Persona unaP) {
        System.out.println(unaP.getNombre() + " DEJA EL SHOP");
    }

}
