/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tpparque;

/**
 *
 * @author Fabio
 */
public class Persona extends Thread{
    private int nombre,acompañante,numeroLlave,restaurante,paseRestaurante;
    private boolean puedoBajar,bici,comio;
    private final Acuario acuario;

    public Persona(int nombre, boolean bici,Acuario acuario) {
        this.nombre = nombre;
     // this.acompañante = -1;
        this.puedoBajar = true;
        this.bici=bici;
        this.restaurante=-1;
        this.comio=false;
        this.paseRestaurante=0;
        this.acuario=acuario;
    }

    public int getNombre() {
        return nombre;
    }
    public int getAcompañante() {
        return acompañante;
    }
       public boolean getDuo() {//
        return true;
    }
    public int getLlave(){
    return numeroLlave;
    }
    public boolean getPuedoBajar() {
        return puedoBajar;
    }
    public int getRestaurante(){
    return restaurante;
    }
    public boolean getComio(){
    return comio;
    }
    public int getPase(){
    return paseRestaurante;}
    public void usoPase(){
    paseRestaurante++;
    }
    public void setComio(boolean x){
    this.comio=x;
    }    
    public void setRestaurante(int x){
    this.restaurante=x;
    }
    public void setNombre(int nombre) {
        this.nombre = nombre;
    }
    public void setAcompañante(int acompañante) {
        this.acompañante = acompañante;
    }
   
    public void setPuedoBajar(boolean puedoBajar) {
        this.puedoBajar = puedoBajar;
    }
    public void setLLave(int llave){
        this.numeroLlave=llave;
    }
    public int getNumeroLlave() {
        return numeroLlave;
    }
    public boolean getBici() {
        return bici;
    }

    @Override
    public void run() {
       acuario.irAlAcuario(this);
    }
    
    
}
