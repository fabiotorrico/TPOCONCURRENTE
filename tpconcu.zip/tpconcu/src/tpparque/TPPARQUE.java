/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tpparque;

import java.util.Random;
import tpparque.Librerias.TecladoIn;

/**
 *
 * @author Fabio
 */
public class TPPARQUE {

    /**
     *Autor TORRICO FABIO FAI-1927
     */
    public static void main(String[] args) {
        int duo, solo, cantTope, cantEscalera,capacidadRes, cantPersonas,cantPlataforma;
        Random random = new Random();
        System.out.println("Cargar Datos de La Carrera De Gomones");
        System.out.println("Ingrese la Cantidad de Gomones Individuales");
        solo = TecladoIn.readLineInt();
        System.out.println("Ingrese la Cantidad de Gomones DUO");
        duo = TecladoIn.readLineInt();
        System.out.println("Ingrese la Cantidad de Gomones que participan de la carrera");
        cantTope = TecladoIn.readLineInt();
        System.out.println("-------------------------------o-------------------------------");
        System.out.println("Cargar Datos del Faro");
        System.out.println("Ingrese la capacidad de la Escalera Caracol del Faro");
        cantEscalera = TecladoIn.readLineInt();
        System.out.println("Ingrese la capacidad de la PLATAFORMA del Faro");
        cantPlataforma = TecladoIn.readLineInt();
                

        System.out.println("-------------------------------o-------------------------------");
        System.out.println("Ingrese Datos De Cada Restaurante");
        Restaurante restaurantes[] = new Restaurante[3];
        for (int i = 0; i < 3; i++) {
            System.out.println("Ingrese la capacidad del Restaurante " + i + " <");
            capacidadRes = TecladoIn.readLineInt();
            restaurantes[i] = new Restaurante( capacidadRes,i);
        }
        System.out.println("-------------------------------o-------------------------------");
        System.out.println("Ingrese La cantidad de Personas que van a usar el Parque");
        cantPersonas = TecladoIn.readLineInt();

        Bolsa colBolsas[] = new Bolsa[cantPersonas];
        for (int i = 0; i < cantPersonas; i++) {
            colBolsas[i] = new Bolsa(i, false);
        }

        System.out.println("-------------------------------o-------------------------------");
        Faro unFaro = new Faro(cantEscalera,cantPlataforma);
        CarreraDeGomones unaCa = new CarreraDeGomones(solo, duo, cantTope, colBolsas);
        Snorkel unSnorkel= new Snorkel(7);// 7 conjuntos
        NadoConDelfines unDelf = new NadoConDelfines();
        Parque parque = new Parque(unaCa, unFaro, restaurantes, unSnorkel,unDelf);
        Acuario acuario= new Acuario(5, parque);

        Persona personas[] = new Persona[cantPersonas];
        for (int i = 0; i < cantPersonas; i++) {
            personas[i] = new Persona(i, random.nextBoolean(), acuario);
            i++;
        }

        System.out.println("-------------------------------o-------------------------------");

        Reloj hora = new Reloj(parque);
        hora.start();
        for (int i = 0; i < cantPersonas; i++) {
            personas[i].start();
           
        }                
        Camioneta camioneta = new Camioneta("LA HILUX", parque,unaCa);
        camioneta.start();
    }

}
