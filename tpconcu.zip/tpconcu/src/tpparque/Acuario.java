/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tpparque;

import java.util.Random;
import java.util.concurrent.BrokenBarrierException;
import java.util.concurrent.CyclicBarrier;
import java.util.concurrent.Semaphore;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

/**
 *
 * @author fabio
 */
public class Acuario {
    private final Semaphore molinete;
    private final CyclicBarrier colectivo;
    private Parque parque;
    private Shop shop;
    private Boolean abierto;
    
    public Acuario (int molinetes, Parque parquee){
    this.parque=parquee;
    this.shop=new Shop();
    this.molinete= new Semaphore(molinetes);
    this.colectivo= new CyclicBarrier(25);
    this.abierto=false;
   
    
    }
    public void setAbierto(Boolean abiertoo){
    this.abierto=abiertoo;
    }
    private void entrar(Persona unaP){
        try {
            if (abierto) {
            molinete.acquire(1);
            System.out.println(unaP.getNombre()+" Entro al acuario ");
            molinete.release();
            elegirDestino(unaP);
            } else {
            System.out.println(unaP.getNombre()+" NO ENTRO AL ACUARIO POR QUE ESTA CERRADO ");
            }
          
        } catch (InterruptedException ex) {          
        }    
    }
    
    public void irAlAcuario(Persona unaP){
        try {
            Random r = new Random();
            if (r.nextBoolean()) {
                System.out.println(unaP.getNombre()+"Viene en forma Particular");
                simulacionViaje();
                System.out.println(unaP.getNombre()+"LLEGO al Acuario");
            } else {
                System.out.println(unaP.getNombre()+"Viene en TOUR");
                colectivo(unaP);
                simulacionViaje();
                System.out.println(unaP.getNombre()+"LLEGO al Acuario en el COLECTIVO DEL TOUR");
            }
            entrar(unaP);         
        } catch (Exception e) {
        }
    }
    private void colectivo(Persona unaP){
         System.out.println(unaP.getNombre() + "Subio al Colectivo");
            try {
              colectivo.await(10, TimeUnit.SECONDS);
            } catch (InterruptedException | BrokenBarrierException x) {
            } catch (TimeoutException ex) {
              colectivo.reset();
            }
    }
    private void elegirDestino(Persona unaP){
    Random r= new Random();
        switch(r.nextInt(4)){
            case 0:
                parque.entrarParque(unaP);
                shop.ingreso(unaP);
                shop.salir(unaP);
                break;
            case 1:
                shop.ingreso(unaP);
                shop.salir(unaP);
                parque.entrarParque(unaP);               
                break;                
            case 2:
                shop.ingreso(unaP);
                shop.salir(unaP);
                break;               
            case 3:
                parque.entrarParque(unaP);           
                break;
        }
        System.out.println(unaP.getNombre()+" ABANDONA EL ACUARIO");
    }
    
    private void simulacionViaje(){
        Random r= new Random();       
        try {
            Thread.sleep(1000*(r.nextInt(3)+1));
        } catch (Exception e) {
        }
    }
}
