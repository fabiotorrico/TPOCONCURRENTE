/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tpparque;

import java.util.Random;
import java.util.concurrent.Semaphore;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Fabio
 */
public class Faro {
    
    private Semaphore escaleraCaracol;
    private Semaphore toboganA;
    private Semaphore toboganB;
    private Semaphore admin;
    private Semaphore capacidadFaro;
    
    public Faro(int n, int x) {
        this.escaleraCaracol = new Semaphore(n, true);
        this.capacidadFaro = new Semaphore(x, true);
        this.toboganA = new Semaphore(1, true);
        this.toboganB = new Semaphore(1, true);
        this.admin = new Semaphore(1, true);
    }
    
    public void ingresar(Persona unaP) {
        try {
            if (capacidadFaro.tryAcquire()) {
                System.out.println("Ingreso al Faro" + unaP.getNombre());
                subirEscalera(unaP);
            } else {
                System.out.println("La PLATAFORMA DEL FARO esta a tope \n"
                        + "Haciendo FILA para INGRESAR AL FARO" + unaP.getNombre());
                capacidadFaro.acquire();
                subirEscalera(unaP);
                
            }
        } catch (Exception e) {
        }
        
    }
    
    private void subirEscalera(Persona unaP) {
        //El metodo sube la escalera caracol controlando la cantidad de personas que suben simultaneamente

        try {
            if (escaleraCaracol.tryAcquire()) {
                subir(unaP);
            } else {
                System.out.println("La escalera esta llena va a esperar que se libere");
                escaleraCaracol.acquire(1);
                subir(unaP);
            }
        } catch (InterruptedException ex) {
            
        }
        
    }
    
    private void subir(Persona unaP) {
        Random r = new Random();
        
        try {            
            System.out.println(unaP.getNombre() + " Esta Subiendo la escalera Caracol");
            Thread.sleep(1000 * (r.nextInt(4) + 1));
            System.out.println(unaP.getNombre() + " LLego a la cima");
            escaleraCaracol.release();
        } catch (InterruptedException ex) {
            
        }
        
    }
    
    public void bajarPorElTobogan(Persona unaP) {
        //El metodo se encarga de controlar que en cada tobogan bajen de a uno.Como asi tambien un administrador
        //decide quien baja por que tobogan.
        Random r = new Random();
        int t = r.nextInt(2);
        try {
            if (t == 0) {
                try {
                    admin.acquire(1);
                    System.out.println("El administrador decide que " + unaP.getNombre() + " va por el tobogan >> A");
                    admin.release();
                } catch (InterruptedException ex) {
                    Logger.getLogger(Faro.class.getName()).log(Level.SEVERE, null, ex);
                }
                
                toboganA.acquire(1);
                System.out.println(unaP.getNombre() + " Baja Por el Tobogan << A ");
                Thread.sleep(1000 * (r.nextInt(4) + 1));
                System.out.println(unaP.getNombre() + " Ya Bajo < ");
                toboganA.release();
            } else {
                try {
                    admin.acquire(1);
                    System.out.println("El administrador decide que " + unaP.getNombre() + " va por el tobogan >> B");
                    admin.release();
                } catch (InterruptedException ex) {
                    Logger.getLogger(Faro.class.getName()).log(Level.SEVERE, null, ex);
                }
                toboganB.acquire(1);
                System.out.println(unaP.getNombre() + " Baja Por el Tobogan << B");
                Thread.sleep(1000 * (r.nextInt(4) + 1));
                System.out.println(unaP.getNombre() + " Ya Bajo < ");
                toboganB.release();
            }
            capacidadFaro.release();// Descuento uno de los lugares de la Plataforma
        } catch (Exception e) {
        }
        
    }
}
