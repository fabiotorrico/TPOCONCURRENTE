/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tpparque;

import java.util.Random;
import java.util.concurrent.Semaphore;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Fabio
 */
public class Snorkel {
    private Semaphore conjuntos;
    private Semaphore recepcionista;
    
    public Snorkel(int cantidad){
    conjuntos= new Semaphore(cantidad, true);
    recepcionista= new Semaphore(2, true);
    }
    
    public void entrar(Persona unaP){
        System.out.println(unaP.getNombre()+"Entro a la Laguna");
    }
    
    public void adquirirAccesorios(Persona unaP){  
        
        try {
            
            if (recepcionista.tryAcquire()) {
                System.out.println("El recepcionista atiende al Cliente >>"+unaP.getNombre());
                adquirirConjuntos(unaP);
            } else {
                System.out.println("El recepcionista esta atendiendo Ocupado ESPERA");
                recepcionista.acquire();
                System.out.println("El recepcionista atiende al Cliente >>"+unaP.getNombre());
                adquirirConjuntos(unaP);
            }
            
            
        } catch (InterruptedException ex) {}
    }
    private void adquirirConjuntos(Persona unaP){
        try {
            if (conjuntos.tryAcquire()) { //Intento Tomar un Conjunto Para realizar la Actividad.
                System.out.println(unaP.getNombre()+" Adquirio el Salvavida y las Patas de Rana");
                recepcionista.release();
            }else {// Sino Consique espera a tomar un Conjunto
                recepcionista.release();
                System.out.println(unaP.getNombre()+" No pudo adquirir el equipo y espera a que se libere alguno");
                conjuntos.acquire();// Toma el conjunto cuando se Libere uno
                System.out.println(unaP.getNombre()+" Adquirio el Salvavida y las Patas de Rana");
        }           
        } catch (Exception e) {
        }
    }
    
    public void simulacionActividad(){
        //El Modulo simula que realiza la Actividad
    Random r= new Random();
        try {
            Thread.sleep(r.nextInt(4)*1000);
        } catch (InterruptedException ex) {
            Logger.getLogger(Snorkel.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void terminarActividad(Persona unaP){
        //El modulo informa que termino la Actividad y Devuelve el conjunto de accesorios.
        System.out.println(unaP.getNombre()+"Termino la Actividad");
        conjuntos.release();
        System.out.println(unaP.getNombre()+" Devolvio el Salvavida y las Patas de Rana");
    }    
}
