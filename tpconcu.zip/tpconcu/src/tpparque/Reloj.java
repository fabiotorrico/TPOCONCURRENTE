/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tpparque;

import com.sun.xml.internal.bind.v2.runtime.output.SAXOutput;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Fabio
 */
public class Reloj extends Thread {

    private int horas, minutos, segundos;
    private Acuario acuario;
    private Parque parque;

    public Reloj(Parque unP) {
        this.horas = 8;
        this.minutos = 0;
        this.segundos = 0;
       this.parque=unP;
    }

    private void simulacion() throws InterruptedException {
        System.out.println(" SIMU");
        Random r = new Random();
        Thread.sleep(1000 * (r.nextInt(3) + 1));
        segundos = segundos + r.nextInt(60);
        minutos = minutos + r.nextInt(30);
        horas = horas + (r.nextInt(3) + 1);
        if (segundos > 60) {
            minutos++;
            segundos = segundos - 60;
        }
        if (minutos > 60) {
            horas++;
            minutos = minutos - 60;
        }
        if (horas > 24) {
            horas = 0;
        }
        System.out.println(" F SIMU");

    }

    @Override
    public String toString() {
        String reloj = " ----------- Reloj | ";
        if (horas < 10) {
            reloj = reloj + "0" + horas  +" : ";
        } else {
            reloj = reloj + horas+" : ";
        }
        if (minutos < 10) {
            reloj = reloj + "0" + minutos+" : ";
        } else {
            reloj = reloj + minutos+" : ";
        }
        if (segundos < 10) {
            reloj = reloj + "0" + segundos;
        } else {
            reloj = reloj + segundos;
        }
        reloj= reloj +"| -----------";
        
        return reloj;
    }

    @Override
    public void run() {
        while (true) {
            try {
                if ((horas > 8 && minutos >= 0) && (horas < 18 && minutos <= 60)) {
                  acuario.setAbierto(true);
                }else{
                acuario.setAbierto(false);
                }
                if ((horas > 8 && minutos >= 0) && (horas < 17 && minutos <= 60)) {
                parque.setAbierto(true);
                }else{
                parque.setAbierto(false);
                }
                simulacion();
                System.out.println(this.toString());
            } catch (InterruptedException ex) {
                Logger.getLogger(Reloj.class.getName()).log(Level.SEVERE, null, ex);
            }

        }
    }

}
