/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tpparque;

import java.util.Random;
import java.util.concurrent.BrokenBarrierException;
import java.util.concurrent.CyclicBarrier;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Fabio
 */
public class NadoConDelfines {

    private int pile1, pile2, pile3, pile4;
    private Condition pileta1, pileta2, pileta3, pileta4;
    private Condition espera1, espera2, espera3, espera4;
    private Lock lock;
    private CyclicBarrier PiletasListas;
    private boolean p1, p2, p3, p4;

    public NadoConDelfines() {
        this.lock = new ReentrantLock();
        this.p1 = true;
        this.p2 = true;
        this.p3 = true;
        this.p4 = true;
        this.pile1 = 4;
        this.pile2 = 4;
        this.pile3 = 4;
        this.pile4 = 4;

        this.pileta1 = lock.newCondition();
        this.pileta2 = lock.newCondition();
        this.pileta3 = lock.newCondition();
        this.pileta4 = lock.newCondition();
        this.espera1 = lock.newCondition();
        this.espera2 = lock.newCondition();
        this.espera3 = lock.newCondition();
        this.espera4 = lock.newCondition();

        this.PiletasListas = new CyclicBarrier(3);
    }

    public void entroPile1(Persona unaP) throws InterruptedException {

        lock.lock();
        while (!p1 || !(pile1 > 0)) {
            System.out.println(unaP.getNombre() + "  No hay Lugar en la Pile 1 ESPERO");
            espera1.await();

        }
        System.out.println(unaP.getNombre() + "  Entro a la Pile 1");

        if (pile1 > 1) {
            pile1--;
            pileta1.await();
            if (p1) {
                p1 = false;
            }

        }
        lock.unlock();
        if (pile1 == 1) {
            pile1--;

            try {
                PiletasListas.await();
                System.out.println(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>><<<SE ROMPIO LA PILETA 1");
                lock.lock();
                pileta1.signalAll();
                pileta2.signalAll();
                pileta3.signalAll();
                pileta4.signalAll();
                lock.unlock();
            } catch (BrokenBarrierException ex) {
            }

        }
    }

    public void nadar1(Persona unaP) {
        try {
            System.out.println(unaP.getNombre() + " Empezo a nadar en la Pileta 1");
            Thread.sleep(1000);
        } catch (InterruptedException ex) {
            Logger.getLogger(NadoConDelfines.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void salirPile1(Persona unaP) {
        lock.lock();
        pile1++;
        if (pile1 == 4) {
            p1 = true;
            espera1.signalAll();
        }
        System.out.println(unaP.getNombre() + " Salio de la Pileta 1");
        lock.unlock();

    }

    public void entroPile2(Persona unaP) throws InterruptedException {
        lock.lock();
        while ((!p2) || !(pile2 > 0)) {
            System.out.println(unaP.getNombre() + " No hay Lugar en la Pile 22 ESPERO");
            espera2.await();

        }
        System.out.println(unaP.getNombre() + "  Entro a la Pile 22");

        if (pile2 > 1) {
            pile2--;
            pileta2.await();
            if (p2) {
                p2 = false;
            }

        }
        lock.unlock();
        if (pile2 == 1) {
            pile2--;
            try {
                PiletasListas.await();
                System.out.println(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>><<<SE ROMPIO LA PILETA 2");
                lock.lock();
                pileta1.signalAll();
                pileta2.signalAll();
                pileta3.signalAll();
                pileta4.signalAll();
                lock.unlock();
            } catch (BrokenBarrierException ex) {
            }
        }
    }

    public void nadar2(Persona unaP) {
        try {
            System.out.println(unaP.getNombre() + " Empezo a nadar en la Pileta 2");
            Thread.sleep(1000);
        } catch (InterruptedException ex) {
            Logger.getLogger(NadoConDelfines.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void salirPile2(Persona unaP) {
        lock.lock();
        pile2++;
        if (pile2 == 4) {
            p2 = true;
            espera2.signalAll();
        }
        System.out.println(unaP.getNombre() + " Salio de la Pileta 2");
        lock.unlock();

    }

    public void entroPile3(Persona unaP) throws InterruptedException {
        lock.lock();
        while ((!p3) || !(pile3 > 0)) {
            System.out.println(unaP.getNombre() + " No hay Lugar en la Pile 333 ESPERO");
            espera3.await();

        }
        System.out.println(unaP.getNombre() + "  Entro a la Pile 333");

        if (pile3 > 1) {
            pile3--;
            pileta3.await();
            if (p3) {
                p3 = false;
            }

        }
        lock.unlock();
        if (pile3 == 1) {
            pile3--;
            try {
                PiletasListas.await();
                System.out.println(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>><<<SE ROMPIO LA PILETA 3");
                lock.lock();
                pileta1.signalAll();
                pileta2.signalAll();
                pileta3.signalAll();
                pileta4.signalAll();
                lock.unlock();
            } catch (BrokenBarrierException ex) {
            }

        }
    }

    public void nadar3(Persona unaP) {

        try {
            System.out.println(unaP.getNombre() + " Empezo a nadar en la Pileta 3");
            Thread.sleep(1000);
        } catch (InterruptedException ex) {

        }

    }

    public void salirPile3(Persona unaP) {
        lock.lock();
        pile3++;
        if (pile3 == 4) {
            p3 = true;
            espera3.signalAll();
        }
        System.out.println(unaP.getNombre() + " Salio de la Pileta 3");
        lock.unlock();

    }

    public void entroPile4(Persona unaP) throws InterruptedException {
        lock.lock();
        while (!p4 || !(pile4 > 0)) {
            System.out.println(unaP.getNombre() + "  No hay Lugar en la Pile 4444 ESPERO");
            espera4.await();

        }
        System.out.println(unaP.getNombre() + " Entro a la Pile 4444");

        if (pile4 > 1) {
            pile4--;
            pileta4.await();
            if (p4) {
                p4 = false;
            }

        }
        lock.unlock();
        if (pile4 == 1) {
            pile4--;
            try {
                PiletasListas.await();
                System.out.println(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>><<<SE ROMPIO LA PILETA 4 ");
                lock.lock();
                pileta1.signalAll();
                pileta2.signalAll();
                pileta3.signalAll();
                pileta4.signalAll();
                lock.unlock();
            } catch (BrokenBarrierException ex) {
            }
        }
    }

    public void nadar4(Persona unaP) {
        try {
            System.out.println(unaP.getNombre() + " Empezo a nadar en la Pileta 4");
            Thread.sleep(1000);
        } catch (InterruptedException ex) {

        }
    }

    public void salirPile4(Persona unaP) {
        lock.lock();
        pile4++;
        if (pile4 == 4) {
            p4 = true;
            espera4.signalAll();
        }
        System.out.println(unaP.getNombre() + " Salio de la Pileta 4");
        lock.unlock();

    }

    public void excepcion() {
        lock.lock();
        espera1.signalAll();
        espera2.signalAll();
        espera3.signalAll();
        espera4.signalAll();
        pileta1.signalAll();
        pileta2.signalAll();
        pileta3.signalAll();
        pileta4.signalAll();
        p1=false;
        p2=false;
        p3=false;
        p4=false;
        
        lock.unlock();
    }

}
